"""
SQL Query Expert pipeline — natural language → PostgreSQL → one-line answer.

Ported from sql_query_expert_v5.1.ipynb (Steps 6 + 10) and adapted for the server:
- psycopg2 (sync)      → asyncpg (async, read-only session, statement timeout)
- google-genai direct  → the platform's LLMService abstraction (any LLM_PROVIDER)
- input() ambiguity menu → TABLE_NOTES business rules (services/sql_expert/table_notes.py)
- printed SQL + DataFrame → SqlExpertResult whose .answer is ONE human sentence

Flow per question:
    gate (LLM: answerable from this schema?)  → None on refusal ⇒ caller falls back
    generate (LLM, ≤3 attempts w/ error feedback)
    validate (validators.py layers 1-3)
    EXPLAIN dry-run (layer 4)
    execute read-only + LIMIT cap (layer 5)
    summarize (LLM: one short sentence, never SQL)
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

import structlog

from config import Settings
from routers.prompts import (
    SQL_FEW_SHOT_EXAMPLES,
    SQL_GATE_PROMPT,
    SQL_GENERATION_SYSTEM,
    SQL_SUMMARIZER_PROMPT,
)
from services.llm.json_parser import extract_json
from services.llm.provider import LLMService
from services.sql_expert.schema import SchemaCache
from services.sql_expert.validators import add_limit, tables_in, validate_sql

log = structlog.get_logger()

_MAX_ATTEMPTS = 3
_SUMMARY_ROW_CAP = 50  # rows sent to the summarizer LLM
_STATEMENT_TIMEOUT_MS = 15_000


@dataclass
class SqlExpertResult:
    answer: str  # the one-line human answer — the only thing the user sees
    sql: str  # kept for structlog debugging, never sent to the user
    tables_used: list[str]
    row_count: int


class SqlExpert:
    def __init__(self, llm: LLMService, settings: Settings) -> None:
        self._llm = llm
        self._settings = settings
        self._schema = SchemaCache(db_schema=settings.sql_expert_db_schema)

    # ── connections ──────────────────────────────────────────────────────────

    async def _connect(self) -> Any:
        import asyncpg  # local import: only needed when the feature is enabled

        s = self._settings
        return await asyncpg.connect(
            host=s.sql_expert_db_host,
            port=s.sql_expert_db_port,
            database=s.sql_expert_db_name,
            user=s.sql_expert_db_user,
            password=s.sql_expert_db_password.get_secret_value(),
            timeout=10,
            server_settings={
                "default_transaction_read_only": "on",
                "statement_timeout": str(_STATEMENT_TIMEOUT_MS),
            },
        )

    # ── LLM helpers ──────────────────────────────────────────────────────────

    async def _llm_json(self, system: str, user: str, max_tokens: int = 1024) -> dict[str, Any]:
        result = await self._llm.chat(system=system, user=user, max_tokens=max_tokens)
        parsed = extract_json(result.content)
        if not isinstance(parsed, dict):
            raise ValueError("LLM reply was not a JSON object")
        return parsed

    async def _gate(self, question: str) -> bool:
        """Answerability gate. Fails CLOSED: any parse problem ⇒ not answerable."""
        prompt = SQL_GATE_PROMPT.format(
            schema_context=self._schema.schema_context(), question=question
        )
        try:
            data = await self._llm_json(system="", user=prompt, max_tokens=512)
        except Exception:
            log.info("sql_expert.gate_unreadable", question=question[:120])
            return False
        answerable = bool(data.get("answerable"))
        if not answerable:
            log.info(
                "sql_expert.gate_refused",
                question=question[:120],
                reason=str(data.get("reason", ""))[:200],
            )
        return answerable

    async def _generate_sql(self, question: str, previous_error: str | None) -> tuple[str, str]:
        prompt = (
            SQL_GENERATION_SYSTEM
            + f"\nALLOWED TABLES (use no others): {', '.join(sorted(self._schema.known_tables))}\n"
            + "\nDatabase schema (including notes you MUST follow):\n"
            + self._schema.schema_context()
            + "\nExamples:\n"
            + SQL_FEW_SHOT_EXAMPLES
            + f"\nQuestion: {question}\nAnswer with raw JSON only."
        )
        if previous_error:
            prompt += (
                f"\n\nIMPORTANT: your previous attempt failed with this error:\n"
                f"{previous_error}\nFix the query and answer with raw JSON only."
            )
        try:
            data = await self._llm_json(system="", user=prompt, max_tokens=1024)
        except Exception:
            return "", "Model returned unreadable output."
        return (str(data.get("sql") or "")).strip(), (str(data.get("explanation") or "")).strip()

    async def _summarize(self, question: str, rows: list[dict[str, Any]]) -> str:
        shown = rows[:_SUMMARY_ROW_CAP]
        truncated_note = (
            f", showing first {_SUMMARY_ROW_CAP}" if len(rows) > _SUMMARY_ROW_CAP else ""
        )
        prompt = SQL_SUMMARIZER_PROMPT.format(
            question=question,
            row_count=len(rows),
            truncated_note=truncated_note,
            rows_json=json.dumps(shown, default=str, ensure_ascii=False),
        )
        result = await self._llm.chat(system="", user=prompt, max_tokens=256)
        return result.content.strip()

    # ── public API ───────────────────────────────────────────────────────────

    async def try_answer(self, question: str) -> SqlExpertResult | None:
        """Answer a question from PostgreSQL, or return None so the caller can
        fall back to the regular context chat. Never raises for gate refusals;
        connection/DB errors DO raise so the caller can log and fall back."""
        conn = await self._connect()
        try:
            await self._schema.ensure_loaded(conn)
            if not self._schema.known_tables:
                return None

            if not await self._gate(question):
                return None

            error: str | None = None
            for attempt in range(1, _MAX_ATTEMPTS + 1):
                sql_text, explanation = await self._generate_sql(question, error)
                if not sql_text:
                    log.info("sql_expert.no_sql", reason=explanation[:200])
                    return None

                ok, reason = validate_sql(
                    sql_text,
                    {t.lower() for t in self._schema.known_tables},
                    self._schema.table_columns,
                )
                if not ok:
                    log.info("sql_expert.rejected", attempt=attempt, reason=reason[:200])
                    error = reason
                    continue

                # Layer 4: EXPLAIN dry-run — PostgreSQL plans without executing
                try:
                    await conn.execute("EXPLAIN " + sql_text.rstrip().rstrip(";"))
                except Exception as exc:
                    error = str(exc).strip()
                    log.info("sql_expert.explain_failed", attempt=attempt, error=error[:200])
                    continue

                # Layer 5: read-only execution, row-capped
                try:
                    records = await conn.fetch(
                        add_limit(sql_text, self._settings.sql_expert_max_rows)
                    )
                except Exception as exc:
                    error = str(exc).strip()
                    log.info("sql_expert.execute_failed", attempt=attempt, error=error[:200])
                    continue

                rows = [dict(r) for r in records]
                answer = await self._summarize(question, rows)
                used = tables_in(sql_text)
                log.info(
                    "sql_expert.answered",
                    tables=used,
                    rows=len(rows),
                    sql=sql_text[:500],
                )
                return SqlExpertResult(
                    answer=answer, sql=sql_text, tables_used=used, row_count=len(rows)
                )

            log.warning(
                "sql_expert.gave_up", attempts=_MAX_ATTEMPTS, last_error=(error or "")[:200]
            )
            return None
        finally:
            await conn.close()
