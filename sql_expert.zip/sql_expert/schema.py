"""
Async PostgreSQL schema introspection (notebook Steps 3-4, psycopg2 → asyncpg).

Builds two artifacts on first use, then caches them in-process:
- ``schema_text``   — human-readable schema (tables, columns, PK/FK) that goes
  into every LLM prompt
- ``table_columns`` — ``{table: {columns}}`` catalog the validators use to
  reject invented tables/columns

``schema_context()`` appends the TABLE_NOTES / GENERAL_RULES business rules
(notebook Step 4b) so every model call sees them.
"""

from __future__ import annotations

import asyncio
from typing import Any

import structlog

from services.sql_expert.table_notes import GENERAL_RULES, TABLE_NOTES

log = structlog.get_logger()

_TABLES_SQL = """
SELECT table_name FROM information_schema.tables
WHERE table_schema = $1 AND table_type = 'BASE TABLE'
ORDER BY table_name
"""

_COLUMNS_SQL = """
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_schema = $1 AND table_name = $2
ORDER BY ordinal_position
"""

_PK_SQL = """
SELECT a.attname AS col FROM pg_index i
JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY(i.indkey)
WHERE i.indrelid = $1::regclass AND i.indisprimary
"""

_FK_SQL = """
SELECT kcu.column_name AS col, ccu.table_name AS ref_table,
       ccu.column_name AS ref_col
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu
  ON tc.constraint_name = kcu.constraint_name AND tc.table_schema = kcu.table_schema
JOIN information_schema.constraint_column_usage ccu
  ON ccu.constraint_name = tc.constraint_name AND ccu.table_schema = tc.table_schema
WHERE tc.constraint_type = 'FOREIGN KEY'
  AND tc.table_schema = $1 AND tc.table_name = $2
"""


class SchemaCache:
    """Lazily introspects the database once and caches the result.

    ``conn`` objects are asyncpg connections supplied by the caller
    (pipeline.py owns connection creation so credentials live in one place).
    """

    def __init__(self, db_schema: str = "public") -> None:
        self._db_schema = db_schema
        self._lock = asyncio.Lock()
        self.schema_text: str = ""
        self.table_columns: dict[str, set[str]] = {}
        self.known_tables: list[str] = []

    @property
    def loaded(self) -> bool:
        return bool(self.known_tables)

    async def ensure_loaded(self, conn: Any) -> None:
        if self.loaded:
            return
        async with self._lock:
            if self.loaded:
                return
            await self._load(conn)

    async def refresh(self, conn: Any) -> None:
        async with self._lock:
            await self._load(conn)

    async def _load(self, conn: Any) -> None:
        tables = [r["table_name"] for r in await conn.fetch(_TABLES_SQL, self._db_schema)]
        lines: list[str] = []
        table_columns: dict[str, set[str]] = {}

        for t in tables:
            cols = await conn.fetch(_COLUMNS_SQL, self._db_schema, t)
            table_columns[t.lower()] = {c["column_name"].lower() for c in cols}

            try:
                pks = {r["col"] for r in await conn.fetch(_PK_SQL, f'{self._db_schema}."{t}"')}
            except Exception:
                pks = set()
            fks = await conn.fetch(_FK_SQL, self._db_schema, t)

            lines.append(f"TABLE {t} (")
            for c in cols:
                pk = " PRIMARY KEY" if c["column_name"] in pks else ""
                nn = "" if c["is_nullable"] == "YES" else " NOT NULL"
                lines.append(f"    {c['column_name']} {c['data_type']}{nn}{pk}")
            for fk in fks:
                lines.append(
                    f"    FOREIGN KEY ({fk['col']}) REFERENCES {fk['ref_table']}({fk['ref_col']})"
                )
            lines.append(")\n")

        self.known_tables = tables
        self.table_columns = table_columns
        self.schema_text = "\n".join(lines)
        log.info("sql_expert.schema_loaded", tables=len(tables))

    def schema_context(self) -> str:
        """Schema + business rules — what every model call sees (Step 4b)."""
        ctx = self.schema_text
        known_lower = {t.lower() for t in self.known_tables}
        notes = [f"- {t}: {note}" for t, note in TABLE_NOTES.items() if t.lower() in known_lower]
        if notes:
            ctx += "\n\nIMPORTANT notes about these tables (follow them strictly):\n" + "\n".join(
                notes
            )
        if GENERAL_RULES:
            ctx += "\n\nGeneral rules (follow them strictly):\n" + "\n".join(
                f"- {r}" for r in GENERAL_RULES
            )
        return ctx
