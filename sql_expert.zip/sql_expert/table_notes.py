"""
Business rules injected into every SQL Expert prompt (notebook Step 4b).

Column names alone can't tell the model your business rules — e.g. that
`bids_old` holds historical rows that must be COMBINED with `bids` via
UNION ALL for totals and rankings. Notes here are the #1 fix for
"the model only looked in one table" and they replace the notebook's
interactive current/historical/both menu, which a chat endpoint can't show.

Edit freely — one plain-English line per table. Notes for tables that don't
exist in the connected database are silently ignored by schema_context().
"""

from __future__ import annotations

_SPLIT_NOTE = (
    "Historical rows moved out of the main table. The current table `{current}` "
    "is empty or sparse. For totals, counts, 'highest', rankings or any "
    "aggregate question, COMBINE this table with `{current}` using UNION ALL "
    "(never JOIN them to each other) unless the user explicitly says "
    "'current only' or 'historical only'."
)

TABLE_NOTES: dict[str, str] = {
    "bids_old": _SPLIT_NOTE.format(current="bids"),
    "suppliers_old": _SPLIT_NOTE.format(current="suppliers"),
    "customers_old": _SPLIT_NOTE.format(current="customers"),
    "products_old": _SPLIT_NOTE.format(current="products"),
    "rfps_old": _SPLIT_NOTE.format(current="rfps"),
    "bidlineitems_old": _SPLIT_NOTE.format(current="bid_line_items"),
    "rfplineitems_old": _SPLIT_NOTE.format(current="rfp_line_items"),
}

GENERAL_RULES: list[str] = [
    "When a question could be answered from either a current table or its "
    "_old counterpart, default to combining both with UNION ALL and say so "
    "in the explanation.",
]
