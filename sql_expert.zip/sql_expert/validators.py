"""
SQL guardrail validators — ported from sql_query_expert_v5.1.ipynb (Step 8).

Five layers sit between the LLM and the database; this module implements the
first three as pure functions (no I/O, fully unit-testable):

1. Read-only / single statement — rejects writes, DDL, and hidden ";DROP"
2. Table existence            — every FROM/JOIN table must exist (CTE-aware)
3. Column existence           — every alias.column must exist in that table

Layers 4 (EXPLAIN dry-run) and 5 (read-only execution) live in pipeline.py
because they need a database connection.

All functions take the table catalog as parameters instead of module globals
so they can be tested without a database.
"""

from __future__ import annotations

import re

FORBIDDEN = {
    "INSERT",
    "UPDATE",
    "DELETE",
    "DROP",
    "ALTER",
    "TRUNCATE",
    "CREATE",
    "GRANT",
    "REVOKE",
    "MERGE",
    "CALL",
    "COPY",
    "VACUUM",
    "REINDEX",
    "COMMENT",
    "SET",
}

_SQL_STOPWORDS = {
    "ON",
    "WHERE",
    "GROUP",
    "ORDER",
    "LEFT",
    "RIGHT",
    "INNER",
    "OUTER",
    "JOIN",
    "CROSS",
    "FULL",
    "LIMIT",
    "HAVING",
    "UNION",
    "USING",
    "AS",
    "SELECT",
    "WITH",
    "NATURAL",
    "LATERAL",
    "OFFSET",
    "FETCH",
}


def strip_literals(sql_text: str) -> str:
    """Blank out comments, string literals, and fake-FROM function args
    (EXTRACT/SUBSTRING/TRIM/...) so keyword and table scans can't be fooled."""
    s = re.sub(r"/\*.*?\*/", " ", sql_text, flags=re.DOTALL)
    s = re.sub(r"--[^\n]*", " ", s)
    s = re.sub(r"'(?:[^']|'')*'", "''", s)
    s = re.sub(
        r"\b(EXTRACT|SUBSTRING|TRIM|OVERLAY|POSITION)\s*\([^()]*\)",
        r"\1()",
        s,
        flags=re.I,
    )
    return s


def scan_tables(cleaned: str) -> tuple[set[str], dict[str, str], set[str]]:
    """Return (used_tables, alias_map, cte_names) from FROM/JOIN clauses."""
    cte_names = {
        m.group(1).lower() for m in re.finditer(r"\b([A-Za-z_]\w*)\s+AS\s*\(", cleaned, re.I)
    }
    used: set[str] = set()
    alias_map: dict[str, str] = {}
    for m in re.finditer(
        r"\b(?:FROM|JOIN)\s+([A-Za-z_][\w.]*)(?:\s+(?:AS\s+)?([A-Za-z_]\w*))?",
        cleaned,
        re.I,
    ):
        tbl = m.group(1).split(".")[-1].strip('"').lower()
        used.add(tbl)
        alias = m.group(2)
        if alias and alias.upper() not in _SQL_STOPWORDS:
            alias_map[alias.lower()] = tbl
        alias_map.setdefault(tbl, tbl)  # a table is its own alias
    return used, alias_map, cte_names


def validate_sql(
    sql_text: str,
    known_tables: set[str],
    table_columns: dict[str, set[str]],
) -> tuple[bool, str]:
    """Layers 1-3. Returns (ok, reason). All names in the catalogs are lowercase."""
    if not sql_text or not sql_text.strip():
        return False, "Empty query."
    cleaned = strip_literals(sql_text).strip()

    if ";" in cleaned.rstrip(";"):
        return False, "Multiple SQL statements are not allowed."
    first = re.match(r"\s*([A-Za-z]+)", cleaned)
    first_kw = first.group(1).upper() if first else ""
    if first_kw not in ("SELECT", "WITH"):
        return False, f"Only SELECT/WITH queries are allowed (got '{first_kw}')."
    for kw in FORBIDDEN:
        if re.search(rf"\b{kw}\b", cleaned.upper()):
            return False, f"Forbidden keyword found: {kw}."

    known = {t.lower() for t in known_tables}
    used, alias_map, cte_names = scan_tables(cleaned)

    unknown = used - known - cte_names
    if unknown:
        return False, (
            f"Query references tables that do NOT exist in the database: "
            f"{', '.join(sorted(unknown))}. Available tables: {', '.join(sorted(known))}."
        )
    if not (used & known):
        return False, (
            "Query does not use any table from the database — refusing "
            "(questions must be about the platform's data)."
        )

    # Layer 3: every alias.column must exist in that table
    for m in re.finditer(r"\b([A-Za-z_]\w*)\.([A-Za-z_]\w*)\b", cleaned):
        alias, col = m.group(1).lower(), m.group(2).lower()
        tbl = alias_map.get(alias)
        if tbl in table_columns and col != "*" and col not in table_columns[tbl]:
            return False, (
                f"Column '{col}' does not exist in table '{tbl}'. "
                f"Available columns: {', '.join(sorted(table_columns[tbl]))}."
            )
    return True, ""


def tables_in(sql_text: str) -> list[str]:
    """Real (non-CTE) tables referenced by the query — used for logging."""
    used, _, cte = scan_tables(strip_literals(sql_text))
    return sorted(used - cte)


def add_limit(sql_text: str, max_rows: int) -> str:
    """Cap result size unless the query already has a LIMIT."""
    if re.search(r"\bLIMIT\s+\d+", sql_text, re.I):
        return sql_text
    return sql_text.rstrip().rstrip(";") + f" LIMIT {max_rows};"
